package com.xms.bean;

import java.util.List;

/**
 * Created by dell on 2017/8/8.
 */

public class PcbbBean {

    /**
     * curDateTime : 1502186251373
     * info : 操作完成
     * recode : 10001000
     * result : {"contractDateValue":1080000,"dateValue":115984,"differRatio":-0.5839,"iegCustomerList":[{"contractDataValue":1085000,"dataValue":115984,"differRatio":-0.5858,"id":"2597d9e6-3c74-47f1-aeac-94d6b57cb42b","name":"莫奈瓷砖"}],"month":8,"year":2017}
     * sessionId : 9A216F2404C5C39F414E69C70C3F6755
     * status : y
     * success : true
     */

    private long curDateTime;
    private String info;
    private int recode;
    private ResultBean result;
    private String sessionId;
    private String status;
    private boolean success;

    public long getCurDateTime() {
        return curDateTime;
    }

    public void setCurDateTime(long curDateTime) {
        this.curDateTime = curDateTime;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public int getRecode() {
        return recode;
    }

    public void setRecode(int recode) {
        this.recode = recode;
    }

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public static class ResultBean {
        /**
         * contractDateValue : 1080000
         * dateValue : 115984
         * differRatio : -0.5839
         * iegCustomerList : [{"contractDataValue":1085000,"dataValue":115984,"differRatio":-0.5858,"id":"2597d9e6-3c74-47f1-aeac-94d6b57cb42b","name":"莫奈瓷砖"}]
         * month : 8
         * year : 2017
         */

        private int contractDateValue;
        private int dateValue;
        private double differRatio;
        private int month;
        private int year;
        private List<IegCustomerListBean> iegCustomerList;

        public int getContractDateValue() {
            return contractDateValue;
        }

        public void setContractDateValue(int contractDateValue) {
            this.contractDateValue = contractDateValue;
        }

        public int getDateValue() {
            return dateValue;
        }

        public void setDateValue(int dateValue) {
            this.dateValue = dateValue;
        }

        public double getDifferRatio() {
            return differRatio;
        }

        public void setDifferRatio(double differRatio) {
            this.differRatio = differRatio;
        }

        public int getMonth() {
            return month;
        }

        public void setMonth(int month) {
            this.month = month;
        }

        public int getYear() {
            return year;
        }

        public void setYear(int year) {
            this.year = year;
        }

        public List<IegCustomerListBean> getIegCustomerList() {
            return iegCustomerList;
        }

        public void setIegCustomerList(List<IegCustomerListBean> iegCustomerList) {
            this.iegCustomerList = iegCustomerList;
        }

        public static class IegCustomerListBean {
            /**
             * contractDataValue : 1085000
             * dataValue : 115984
             * differRatio : -0.5858
             * id : 2597d9e6-3c74-47f1-aeac-94d6b57cb42b
             * name : 莫奈瓷砖
             */

            private int contractDataValue;
            private int dataValue;
            private double differRatio;
            private String id;
            private String name;

            public int getContractDataValue() {
                return contractDataValue;
            }

            public void setContractDataValue(int contractDataValue) {
                this.contractDataValue = contractDataValue;
            }

            public int getDataValue() {
                return dataValue;
            }

            public void setDataValue(int dataValue) {
                this.dataValue = dataValue;
            }

            public double getDifferRatio() {
                return differRatio;
            }

            public void setDifferRatio(double differRatio) {
                this.differRatio = differRatio;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }
        }
    }
}
