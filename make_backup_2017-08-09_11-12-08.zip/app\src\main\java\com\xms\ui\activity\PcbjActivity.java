package com.xms.ui.activity;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import com.xms.R;
import com.xms.adapter.BaseRecyclerAdapter;
import com.xms.base.BaseActivity;
import com.xms.bean.PcbbBean;
import com.xms.callback.MyStringCallback;
import com.xms.constants.InterfaceDefinition;
import com.xms.holder.BaseRecyclerHolder;
import com.xms.utils.PreferencesUtil;
import com.xms.utils.StringUtil;
import com.xms.utils.ToastUtil;
import com.xms.widget.timecheck.JudgeDate;
import com.xms.widget.timecheck.MyAlertDialog;
import com.xms.widget.timecheck.ScreenInfo;
import com.xms.widget.timecheck.WheelMain;
import com.zhy.http.okhttp.OkHttpUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import butterknife.BindView;
import butterknife.OnClick;

import static com.xms.R.id.mtime;

public class PcbjActivity extends BaseActivity {

    //    @BindView(R.id.linechart)
//    LineChart mChart;
    @BindView(R.id.activity_pcbj01)
    TextView mtext0;
    @BindView(R.id.pcbb_recyclerview)
    RecyclerView mrecyclerview;
    @BindView(R.id.pcbb_year)
    TextView myear;
    @BindView(R.id.pcbb_month)
    TextView mmonth;
   @BindView(R.id.pcbb_text1)
   TextView mtext11;
    @BindView(R.id.pcbb_text2)
    TextView mtext2;
    @BindView(R.id.pcbb_text3)
    TextView mtext3;
    private ArrayList<PcbbBean.ResultBean.IegCustomerListBean> mlist;
    private BaseRecyclerAdapter<PcbbBean.ResultBean.IegCustomerListBean> madapter;
    private DateFormat dateFormat1 = new SimpleDateFormat("yyyyMM");

    @Override
    public int getContentViewId() {
        return R.layout.activity_pcbj;
    }

    @Override
    public void initData() {
        setTitle();
        mTvForTitle.setText("偏差报表");
        initRecyclerview();
        mtext0.setText((String) PreferencesUtil.get(this,
                InterfaceDefinition.PreferencesUser.SSGS, ""));
        //  initchar();
        Request(dateFormat1.format(new Date()));
        myear.setText(StringUtil.GetMyMessage(dateFormat.format(new Date()),"-")[0]);
        mmonth.setText(StringUtil.GetMyMessage(dateFormat.format(new Date()),"-")[1]);
        mtext.setText(dateFormat.format(new Date()));
    }

    @BindView(mtime)
    TextView mtext;

    @OnClick({R.id.common_title_left, mtime})
    void Onclick(View view) {
        switch (view.getId()) {
            case R.id.common_title_left:
                finish();
                break;
            case mtime:
                time();
                break;
            default:
                break;

        }
    }

    private void Request(final String data) {
        JSONObject object = new JSONObject();
        object.put("ddate", data);
        object.put("companyId", PreferencesUtil.get(this, InterfaceDefinition.PreferencesUser.COMPANYID, ""));
        Log.e("请求报文", "{" + InterfaceDefinition.ICommonKey.REQUEST_DATA + ":" + object.toString() + "}");
        OkHttpUtils
                .post()//
                .url(InterfaceDefinition.Login.URL + "deviateReport.do")//
                .addParams(InterfaceDefinition.ICommonKey.REQUEST_DATA, object.toString())
                .build()
                .execute(new MyStringCallback(PcbjActivity.this) {
                    @Override
                    public void onResponse(String response) {
                        try {
                            Log.e("请求数据", "" + response);
                            JSONObject object = JSON.parseObject(response);
                            if (object.getBoolean("success")) {
                                Gson gson = new Gson();
                                PcbbBean mbean = gson.fromJson(response, PcbbBean.class);
                                mtext11.setText(mbean.getResult().getContractDateValue() + "");
                                mtext2.setText(mbean.getResult().getDateValue() + "");
                                mtext3.setText(mbean.getResult().getDifferRatio() + "");
                                mlist.clear();
                                mlist.addAll(mbean.getResult().getIegCustomerList());
                                madapter.notifyDataSetChanged();
                            } else {
                                ToastUtil.TextToast(object.getString("info"));
                            }
                        } catch (Exception ioex) {
                            ToastUtil.TextToast("请检查网络连接是否正常");
                        }


                    }
                });
    }

    //时间选择器
    private WheelMain wheelMain;
    private DateFormat dateFormat = new SimpleDateFormat("yyyy-MM");

    private void time() {
        LayoutInflater inflater1 = LayoutInflater
                .from(PcbjActivity.this);
        final View timepickerview1 = inflater1.inflate(R.layout.timepicker,
                null);
        ScreenInfo screenInfo1 = new ScreenInfo(PcbjActivity.this);
        wheelMain = new WheelMain(timepickerview1, true, 2);
        wheelMain.screenheight = screenInfo1.getHeight();
        Calendar calendar1 = Calendar.getInstance();
        String time1 = calendar1.get(Calendar.YEAR) + "-"
                + (calendar1.get(Calendar.MONTH) + 1) + "-"
                + calendar1.get(Calendar.DAY_OF_MONTH)
                + calendar1.get(Calendar.HOUR_OF_DAY)
                + calendar1.get(Calendar.MINUTE);
        if (JudgeDate.isDate(time1, "yyyy-mm-dd")) {
            //     if (JudgeDate.isDate(time1, "yyyy-mm")) {
            try {
                calendar1.setTime(dateFormat.parse(time1));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        int year = calendar1.get(Calendar.YEAR);
        int month = calendar1.get(Calendar.MONTH);
        int day = calendar1.get(Calendar.DAY_OF_MONTH);
        //需要精确到分就取消注释
//		int hour = calendar1.get(Calendar.HOUR_OF_DAY);
//		int minute = calendar1.get(Calendar.MINUTE);
        wheelMain.initDateTimePicker(year, month, day
                //, hour, minute
        );
        MyAlertDialog dialog = new MyAlertDialog(PcbjActivity.this)
                .builder().setTitle("选择日期").setView(timepickerview1)
                .setNegativeButton("取消", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                    }
                });
        dialog.setPositiveButton("确定", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String currentDate = "";
                String format = "yyyy-MM-dd  HH:mm";
                // if (DateUtil.timeCompare(DateUtil.getStringDate(format),
                // wheelMain.getTime("%02d"))) {
                currentDate = wheelMain.getTime("%02d");
                //	String time[] = StringUtil.GetMyMessage(currentDate, " ");
                mtext.setText(currentDate);
                Request(StringUtil.GetMessage(currentDate,"-"));
                myear.setText(StringUtil.GetMyMessage(currentDate,"-")[0]);
                mmonth.setText(StringUtil.GetMyMessage(currentDate,"-")[1]);
            }
        });
        dialog.show();
    }

    private void initRecyclerview() {
        mlist = new ArrayList<>();
//        mlist.add(new PcbjBean("莫奈瓷砖","1085000","79232","-0.6766"));
//        for (int i = 0; i < 20; i++) {
//            mlist.add(new PcbjBean("莫奈瓷砖","1085000","79232","-0.6766"));
//        }
        madapter = new BaseRecyclerAdapter<PcbbBean.ResultBean.IegCustomerListBean>(this, mlist, R.layout.adapter_item_pcbb) {
            @Override
            public void convert(BaseRecyclerHolder holder, PcbbBean.ResultBean.IegCustomerListBean item, int position, boolean isScrolling) {
                holder.setText(R.id.adapter_item_pcbb_1, item.getName());
                holder.setText(R.id.adapter_item_pcbb_2, item.getContractDataValue() + "");
                holder.setText(R.id.adapter_item_pcbb_3, item.getDataValue() + "");
                holder.setText(R.id.adapter_item_pcbb_4, item.getDifferRatio() + "");
            }
        };
        mrecyclerview.setLayoutManager(new LinearLayoutManager(this));
        mrecyclerview.setAdapter(madapter);
    }
//    class  PcbjBean{
//
//        public PcbjBean(String name, String htdl, String ydl, String ljpcl) {
//            this.name = name;
//            this.htdl = htdl;
//            this.ydl = ydl;
//            this.ljpcl = ljpcl;
//        }
//
//        public String getName() {
//
//            return name;
//        }
//
//        public void setName(String name) {
//            this.name = name;
//        }
//
//        public String getHtdl() {
//            return htdl;
//        }
//
//        public void setHtdl(String htdl) {
//            this.htdl = htdl;
//        }
//
//        public String getYdl() {
//            return ydl;
//        }
//
//        public void setYdl(String ydl) {
//            this.ydl = ydl;
//        }
//
//        public String getLjpcl() {
//            return ljpcl;
//        }
//
//        public void setLjpcl(String ljpcl) {
//            this.ljpcl = ljpcl;
//        }
//
//        private String name;
//        private String htdl;
//        private String ydl;
//        private String ljpcl;
//    }


//    private Typeface mTfLight;
//    private void initchar(){
//        IAxisValueFormatter custom = new MyAxisValueFormatter(4);//定义的自定义X轴数据
//        XAxis xAxis = mChart.getXAxis();
//        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM); //X轴在底部
//        xAxis.setTypeface(mTfLight);
//        xAxis.setValueFormatter(custom); //添加入X轴数据
//        xAxis.setDrawGridLines(false);
//        xAxis.setGranularity(1f); // only intervals of 1 day
//        xAxis.setLabelCount(7);
//
//        // no description text 没有描述的文本
//        mChart.getDescription().setEnabled(false);
//        // enable touch gestures 支持手势触控
//        mChart.setTouchEnabled(true);
//
//        mChart.setDragDecelerationFrictionCoef(0.9f);
//
//        // enable scaling and dragging 支持缩放和拖动
//        mChart.setDragEnabled(true);
//        mChart.setScaleEnabled(true);
//        mChart.setDrawGridBackground(false);// 是否在折线图上添加边框
//        mChart.setHighlightPerDragEnabled(true);
//        // 如果禁用,扩展可以在x轴和y轴分别完成
//        mChart.setPinchZoom(true);
//        setData(20, 15);
//        mChart.getData().setHighlightEnabled(false);//设置确定线的是否显示
//        mChart.getData().setDrawValues(false);
//        //设置动画
//        mChart.animateX(1500);
//    }
//
//    private void setData(int count, float range) {
//
//        ArrayList<Entry> yVals1 = new ArrayList<Entry>();
//
//        for (int i = 0; i < count; i++) {
//            float mult = range;
//            float val = (float) (Math.random() * mult)/2+10;
//            yVals1.add(new Entry(i, val));
//        }
//
//        ArrayList<Entry> yVals2 = new ArrayList<Entry>();
//
//        for (int i = 0; i < count; i++) {
//            float mult = range;
//            float val = (float) (Math.random() * mult)/2 +12;
//            yVals2.add(new Entry(i, val));
//        }
//
//        ArrayList<Entry> yVals3 = new ArrayList<Entry>();
//
//        for (int i = 0; i < count; i++) {
//            float mult = range;
//            float val = (float) (Math.random() * mult)/2 + 14;
//            yVals3.add(new Entry(i, val));
//        }
//
//        LineDataSet set1 ,set2,set3;
//
//        if (mChart.getData() != null &&
//                mChart.getData().getDataSetCount() > 0) {
//            set1 = (LineDataSet) mChart.getData().getDataSetByIndex(0);
//            set2 = (LineDataSet) mChart.getData().getDataSetByIndex(1);
//            set3 = (LineDataSet) mChart.getData().getDataSetByIndex(2);
//            set1.setValues(yVals1);
//            set2.setValues(yVals2);
//            set3.setValues(yVals3);
//            mChart.getData().notifyDataChanged();
//            mChart.notifyDataSetChanged();
//        } else {
//            // create a dataset and give it a type
//            set1 = new LineDataSet(yVals1, "合同");
//            set2 = new LineDataSet(yVals2, "实际");
//            set3 = new LineDataSet(yVals3, "偏差率");
//            setLineDataSet(set1,getResources().getColor(R.color.chart_1));
//            setLineDataSet(set2,getResources().getColor(R.color.chart_2));
//            setLineDataSet(set3,getResources().getColor(R.color.chart_3));
//
//
//            LineData data = new LineData(set1,set2,set3);
//            data.setValueTextColor(Color.BLACK);
//            data.setValueTextSize(9f);
//            mChart.setData(data);
//        }
//    }
//    private void setLineDataSet(LineDataSet set,int color){
////        set.setAxisDependency(YAxis.AxisDependency.LEFT);
////        set.setColor(color);
////        //  set.setCircleColor(Color.BLACK);//设置圆点颜色
////        set.setLineWidth(1f);
////        //     set.setCircleRadius(1f);//设置小圆点的大小
////        //   set.setFillAlpha(65);
////        set.setFillColor(ColorTemplate.getHoloBlue());
////        //      set.setHighLightColor(Color.rgb(244, 117, 117));
////        set.setDrawCircleHole(false);
////        set.setDrawCircles(false);//去除连接的小圆点
////        //    set.setMode(LineDataSet.Mode.CUBIC_BEZIER);//把线条画成弧形
////        //   set.setHighLightColor(Color.BLACK);//确定线的颜色
//
//        set.setCircleColor(color);//设置圆点颜色
//        set.setCubicIntensity(0.4f);
//        set.setDrawFilled(false);  //设置包括的范围区域填充颜色
//        set.setDrawCircles(true);  //设置有圆点
//        set.setLineWidth(1.0f);    //设置线的宽度
//        set.setCircleSize(2f);   //设置小圆的大小
//        set.setColor(color);
//    }
}
