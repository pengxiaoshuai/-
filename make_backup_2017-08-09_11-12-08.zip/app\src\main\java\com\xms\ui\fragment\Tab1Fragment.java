package com.xms.ui.fragment;

import android.support.v4.view.ViewPager;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.xms.R;
import com.xms.adapter.BaseRecyclerAdapter;
import com.xms.adapter.MyViewPagerAdapter;
import com.xms.base.BaseFragment;
import com.xms.constants.InterfaceDefinition;
import com.xms.holder.BaseRecyclerHolder;
import com.xms.ui.activity.DfcsActivity;
import com.xms.ui.activity.MainActivity;
import com.xms.ui.activity.NhtjActivity;
import com.xms.ui.activity.PcbjActivity;
import com.xms.ui.activity.PcgjActivity;
import com.xms.ui.activity.SdlrjsqActivity;
import com.xms.ui.activity.SsdlActivity;
import com.xms.utils.DividerGridItemDecoration;
import com.xms.utils.PreferencesUtil;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * 首页第一个fragment
 * Created by dell on 2017/2/24.
 */

public class Tab1Fragment extends BaseFragment {
    private View mRootView;
    @BindView(R.id.activity_zy_message_viewpager)
    ViewPager mviewpager;
    @BindView(R.id.activity_zy_message_linlayout)
    LinearLayout mlinlayout;
    @BindView(R.id.mrecyclerview)
    RecyclerView mrecyclerview;
    private View view0,view,view2,view3,view4;
    private ArrayList<View> mlist;
    private MyViewPagerAdapter madapter;
    private ArrayList<ImageView> mlistimage;
    private ImageView mimage;
    private MainActivity mainActivity;

    private ArrayList<MydataBean> mRlist;
    private BaseRecyclerAdapter<MydataBean> mRadapter;
//    @BindView(R.id.drawer_layout)
//    DrawerLayout mdr;
//    @BindView(R.id.left_drawer)
//    LinearLayout mlin_left;
    @Override
    protected View initView(LayoutInflater inflater){
        mRootView = inflater.inflate(R.layout.fragment_tab1, null);
        return mRootView;
    }
    private int currentPosition = 1;
    //初始化数据用的
    @Override
    public void initData(){
        if (!isFirstLoad()){
            return;
        }
        setFirstLoad(false);
        setTitle();
       mImgvForLeft.setVisibility(View.INVISIBLE);
        mainActivity= (MainActivity)getActivity();
        mlist=new ArrayList<>();
        if ((Boolean)PreferencesUtil.get(mContext,
                InterfaceDefinition.PreferencesUser.ZT, false)){
            mTvForTitle.setText( (String)PreferencesUtil.get(mContext,
                    InterfaceDefinition.PreferencesUser.SSGS, ""));
        }else{
        mTvForTitle.setText("暂无所属售电公司");
        }
        LayoutInflater lf = getActivity().getLayoutInflater().from(mContext);
        view0 = lf.inflate(R.layout.adapter_item_viewpager,null);
        view = lf.inflate(R.layout.adapter_item_viewpager,null);
        view2 = lf.inflate(R.layout.adapter_item_viewpager,null);
        view3 = lf.inflate(R.layout.adapter_item_viewpager,null);
        view4 = lf.inflate(R.layout.adapter_item_viewpager,null);
        mimage = (ImageView) view0.findViewById(R.id.adapter_item_viewpager_image);
        mimage.setImageResource(R.mipmap.banner3);
        mlist.add(view0);
        mimage = (ImageView) view.findViewById(R.id.adapter_item_viewpager_image);
        mimage.setImageResource(R.mipmap.banner1);
        mlist.add(view);
        mimage = (ImageView) view2.findViewById(R.id.adapter_item_viewpager_image);
        mimage.setImageResource(R.mipmap.banner2);
        mlist.add(view2);
        mimage = (ImageView) view3.findViewById(R.id.adapter_item_viewpager_image);
        mimage.setImageResource(R.mipmap.banner3);
        mlist.add(view3);
        mimage = (ImageView) view4.findViewById(R.id.adapter_item_viewpager_image);
        mimage.setImageResource(R.mipmap.banner1);
        mlist.add(view4);

        madapter = new MyViewPagerAdapter(mlist);
        mviewpager.setAdapter(madapter);
        mviewpager.setOnPageChangeListener(new ViewPager.OnPageChangeListener(){
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels){

            }

            @Override
            public void onPageSelected(int position){
                if (position == 0){
                    currentPosition = mlist.size() - 2;
                }else if (position == mlist.size() - 1){
                    currentPosition = 1;
                } else {
                    currentPosition = position;
                }
            }

            @Override
            public void onPageScrollStateChanged(int state){
                //当state为SCROLL_STATE_IDLE即没有滑动的状态时切换页面
                //当滑动停下来的时候把所在页面切换到指定页面 0就到3,4就到1，完美循环
                if(state==ViewPager.SCROLL_STATE_IDLE){
                    mviewpager.setCurrentItem(currentPosition,false);//是否需要滑动动画 false
                    setnum(currentPosition);
                }
            }
        });
        setDot();//设置小圆点
        mRlist=new ArrayList<>();
        mRlist.add(new MydataBean(R.mipmap.dldf0,"电费测算","监测每日每月实时电量/费情况"));
        mRlist.add(new MydataBean(R.mipmap.grzx0,"偏差报表","根据合同规定及实际使用计算偏差"));
        mRlist.add(new MydataBean(R.mipmap.nhtj0,"能耗统计","统计各时间段的用电/水/燃气量"));
        mRlist.add(new MydataBean(R.mipmap.ssyd0,"实时电量","显示电/水/燃气/的抄表参数"));
        mRlist.add(new MydataBean(R.mipmap.lrjsq,"利润计算器","根据交易最新规则精准测算可算出利润"));
        mRlist.add(new MydataBean(R.mipmap.pcgj,"偏差告警","设置偏差率告警范围和方式"));
        mRadapter = new BaseRecyclerAdapter<MydataBean>(mContext,mRlist,R.layout.adapter_item_frg1_recyclerview){
            @Override
            public void convert(BaseRecyclerHolder holder, MydataBean item, int position, boolean isScrolling){
                holder.setImageResource(R.id.adapter_image,item.getImage());
                holder.setText(R.id.adapter_text1,item.getMtitle());
                holder.setText(R.id.adapter_text2,item.getMessage());
            }
        };
        mrecyclerview.setLayoutManager(new GridLayoutManager(mContext,2));
        mrecyclerview.addItemDecoration(new DividerGridItemDecoration(mContext));
        mrecyclerview.setAdapter(mRadapter);
        mRadapter.setOnItemClickListener(new BaseRecyclerAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(RecyclerView parent, View view, int position) {
            //    ToastUtil.TextToast(mRlist.get(position).getMtitle());
                switch (position){
                    case 0: //电费测算
                        gotoAct(DfcsActivity.class);
//                        Bundle bundle = new Bundle();
//                        bundle.putInt(DF, 0);
//                        gotoAct(bundle, DldfActivity.class);
                        break;
                    case 1://偏差报表
                        gotoAct(PcbjActivity.class);
                    //    mainActivity.mFragmentTabHost.setCurrentTab(1);
                     //   mainActivity.mradiobutton.setChecked(true);
                        break;
                    case 2:
                        //能耗统计
                        gotoAct(NhtjActivity.class);
                        break;
                    case 3:
                        //实时用电
                     //   gotoAct(SsjcActivity.class);
                        gotoAct(SsdlActivity.class);
                        break;
                    case 4:
                        //利润计算器
                        gotoAct(SdlrjsqActivity.class);
                        break;
                    case 5:
                        //偏差告警
                        gotoAct(PcgjActivity.class);
                        break;
                    default:
                        break;

                }
            }
        });
    }

    //事件监听
    @OnClick({R.id.common_title_left})
    void Onclick(View view){
        switch (view.getId()){
            case R.id.common_title_left:
           //     ToastUtil.TextToast("事件监听ok");
//                mdr.openDrawer(mlin_left);
                break;
            default:
                break;
        }
    }
    private void setDot(){
        mlistimage = new ArrayList<>();
        //设置LinearLayout的子控件的宽高，这里单位是像素
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        params.leftMargin = 0;//左边距
        for (int i = 0; i < mlist.size()-2; i++){
            ImageView imageView = new ImageView(mContext);
            imageView.setLayoutParams(params);
            imageView.setImageResource(R.mipmap.hd01);
            mlinlayout.addView(imageView);
            mlistimage.add(imageView);
        }
        mlistimage.get(0).setImageResource(R.mipmap.ld0);
    }
    private void setnum(int num){
        for (int i = 0; i < mlistimage.size(); i++){
            mlistimage.get(i).setImageResource(R.mipmap.hd01);
        }
        mlistimage.get(num%3).setImageResource(R.mipmap.ld0);
    }
    class MydataBean {
        public MydataBean(int image, String mtitle, String message) {
            this.image = image;
            this.mtitle = mtitle;
            this.message = message;
        }

        private int image;
        private String mtitle;
        private String message;

        public int getImage() {
            return image;
        }

        public void setImage(int image) {
            this.image = image;
        }

        public String getMtitle() {
            return mtitle;
        }

        public void setMtitle(String mtitle) {
            this.mtitle = mtitle;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }
}
