package com.xms.ui.activity;

import android.os.Handler;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.jcodecraeer.xrecyclerview.ProgressStyle;
import com.jcodecraeer.xrecyclerview.XRecyclerView;
import com.xms.R;
import com.xms.adapter.BaseRecyclerAdapter;
import com.xms.base.BaseActivity;
import com.xms.holder.BaseRecyclerHolder;
import com.xms.utils.DividerGridItemDecoration;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.OnClick;


public class BxjllbActivity extends BaseActivity {
    @BindView(R.id.bxjl_recyclerview)
    XRecyclerView mrecyclerview;
    private ArrayList<BxglBean> mlist;
    private BaseRecyclerAdapter<BxglBean> madapter;
    private int times = 0;
    @Override
    public int getContentViewId(){
        return R.layout.activity_bxjllb;
    }

    @Override
    public void initData(){
        setTitle();
        mTvForTitle.setText("报修记录");
        initxrecyclerview();
    }
    @OnClick(R.id.common_title_left)
    void OnClick(View view){
        switch (view.getId()){
            case R.id.common_title_left:
                finish();
                break;
            default:
                break;
        }
    }
    private void initxrecyclerview(){
        mlist = new ArrayList<>();
        madapter = new BaseRecyclerAdapter<BxglBean>(this,mlist,R.layout.adapter_item_bxjl) {
            @Override
            public void convert(BaseRecyclerHolder holder, BxglBean item, int position, boolean isScrolling) {
                holder.setText(R.id.adapter_item_bxjl_text1,item.getTitle());
            }
        };
        mrecyclerview.setLayoutManager(new LinearLayoutManager(this));
        mrecyclerview.addItemDecoration(new DividerGridItemDecoration(this));
        mrecyclerview.setRefreshProgressStyle(ProgressStyle.BallSpinFadeLoader);
        mrecyclerview.setLoadingMoreProgressStyle(ProgressStyle.Pacman);//吃豆豆的动画
        mrecyclerview.setArrowImageView(R.drawable.ic_pulltorefresh_arrow);
//        View header = LayoutInflater.from(this).inflate(R.layout.recyclerview_header, (ViewGroup)findViewById(android.R.id.content),false);
//        mrecyclerview.addHeaderView(header);//可以添加头部布局
        madapter.setOnItemClickListener(new BaseRecyclerAdapter.OnItemClickListener(){
            @Override
            public void onItemClick(RecyclerView parent, View view, int position){
                gotoActivity(BxdActivity.class);
            }
        });
        mrecyclerview.setLoadingListener(new XRecyclerView.LoadingListener(){
            @Override
            public void onRefresh(){
                times = 0;
                new Handler().postDelayed(new Runnable(){
                    public void run(){
                        mlist.clear();
                        for(int i = 0; i < 10 ;i++){
                            mlist.add(new BxglBean("网关无故告警"+i));
                        }
                        madapter.notifyDataSetChanged();
                        mrecyclerview.refreshComplete();//告诉XRecyclerview刷新完毕
                    }
                }, 1000);            //refresh data here
            }

            @Override
                public void onLoadMore(){
                if(times < 2){
                    new Handler().postDelayed(new Runnable(){
                        public void run(){
                            for(int i = 0; i < 10 ;i++){
                                mlist.add(new BxglBean("网关无故告警"+mlist.size()));
                            }
                            mrecyclerview.loadMoreComplete();
                            madapter.notifyDataSetChanged();
                        }
                    }, 1000);
                } else {
                    new Handler().postDelayed(new Runnable() {
                        public void run() {
                            for(int i = 0; i < 9 ;i++){
                                mlist.add(new BxglBean("网关无故告警"+mlist.size()));
                            }
                            mrecyclerview.setNoMore(true); //设置没有更多了
                            madapter.notifyDataSetChanged();
                        }
                    }, 1000);
                }
                times ++;
            }
        });
        mrecyclerview.setAdapter(madapter);
        mrecyclerview.setTransitionName("你好");
        mrecyclerview.refresh();//初次进来刷新
    }
    class BxglBean{
        public String getTitle() {
            return title;
        }

        public void setTitle(String title){
            this.title = title;
        }

        public BxglBean(String title) {
            this.title = title;
        }

        private String title;
    }
}
