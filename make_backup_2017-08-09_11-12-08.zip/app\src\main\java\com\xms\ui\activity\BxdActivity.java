package com.xms.ui.activity;

import android.app.Dialog;
import android.view.View;

import com.xms.R;
import com.xms.base.BaseActivity;
import com.xms.utils.CommonDialog;
import com.xms.utils.ToastUtil;

import butterknife.OnClick;


public class BxdActivity extends BaseActivity {

    @Override
    public int getContentViewId() {
        return R.layout.activity_bxd;
    }

    @Override
    public void initData() {
        setTitle();
        mTvForTitle.setText("报修单");
    }

    @OnClick({R.id.common_title_left, R.id.delete, R.id.goback})
    void OnClick(View view) {
        switch (view.getId()) {
            case R.id.common_title_left:
                finish();
                break;
            case R.id.delete:
                Dialog();
                break;
            case R.id.goback:
                finish();
                break;
            default:
                break;
        }
    }

    private void Dialog() {
        CommonDialog dialog = new CommonDialog(this,
                R.style.dialog);
        dialog.setIcon(R.mipmap.log);
        dialog.setContent("确定删除？");
        dialog.setLeftBtnText("取消");
        dialog.setRightBtnText("确定");
        dialog.setListener(new CommonDialog.DialogClickListener() {

            @Override
            public void onRightBtnClick(Dialog dialog) {
                ToastUtil.TextToast("删除成功");
                finish();
            }

            @Override
            public void onLeftBtnClick(Dialog dialog) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

}
