package com.xms.ui.activity;

import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.xms.R;
import com.xms.base.BaseActivity;
import com.xms.callback.MyStringCallback;
import com.xms.constants.InterfaceDefinition;
import com.xms.utils.MyCountDownTimer;
import com.xms.utils.StringUtil;
import com.xms.utils.ToastUtil;
import com.zhy.http.okhttp.OkHttpUtils;

import butterknife.BindView;
import butterknife.OnClick;


public class ForgetPasswordActivity extends BaseActivity {

    @BindView(R.id.phone)
    EditText phone;
    @BindView(R.id.code)
    EditText code;
    @BindView(R.id.password)
    EditText password;
    @BindView(R.id.password2)
    EditText password2;

    @Override
    public int getContentViewId() {
        return R.layout.activity_forget_password;
    }

    @BindView(R.id.getcode)
    TextView mgetcode;
    private MyCountDownTimer myCountDownTimer;

    @Override
    public void initData() {
        setTitle();
        mTvForTitle.setText("忘记密码");

    }

    @OnClick({R.id.common_title_left, R.id.ok, R.id.back, R.id.getcode})
    void OnClick(View view) {
        switch (view.getId()) {
            case R.id.common_title_left:
                finish();
                break;
            case R.id.ok:
                break;
            case R.id.back:
                finish();
                break;
            case R.id.getcode:
                if (StringUtil.isEmpty(phone.getText().toString().trim())){
                    ToastUtil.TextToast("手机号码为空，请重新输入!");
                    return;
                }
                if (!StringUtil.isMobileNO(phone.getText().toString().trim())){
                    ToastUtil.TextToast("输入的手机号有误！");
                    return;
                }

                Request(phone.getText().toString().trim());

                if (myCountDownTimer != null) {
                    myCountDownTimer.start();
                } else {
                    myCountDownTimer = new MyCountDownTimer(mgetcode, 60000, 1000);
                    myCountDownTimer.start();
                }
                break;
            default:
                break;
        }
    }
    private void Request(final String mobile) {

        JSONObject object = new JSONObject();
        object.put(InterfaceDefinition.Login.MOBILE, mobile);
         Log.e("请求报文", "{" + InterfaceDefinition.ICommonKey.REQUEST_DATA + ":" + object.toString() + "}");
        OkHttpUtils
                .post()//
                .url(InterfaceDefinition.Login.URL + "sendVcode.do")//
                .addParams(InterfaceDefinition.ICommonKey.REQUEST_DATA, object.toString())
                .build()
                .execute(new MyStringCallback(ForgetPasswordActivity.this){
                    @Override
                    public void onResponse(String response){
                        try {
                            JSONObject object1= JSON.parseObject(response);
                            Log.e("请求数据", "" + response);
                            if (object1.getBoolean("success")){
                                ToastUtil.TextToast("验证码发送成功!");
                            }else{
                                ToastUtil.TextToast(object1.getString("info"));
                            }
                        } catch (Exception ioex) {
                            ToastUtil.TextToast("请检查网络连接是否正常");
                        }
                    }
                });
    }
}
