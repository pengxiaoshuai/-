package com.xms.inteface;

import android.view.View;
/**
 *  点击回调接口
 * @author 彭其煊
 * @version 1.0
 * @date 2017.2.24
 */

public interface CommonListener
{
    void commonListener(View view, int position);
}
