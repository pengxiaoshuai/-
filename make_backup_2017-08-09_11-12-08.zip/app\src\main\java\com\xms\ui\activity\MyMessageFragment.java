package com.xms.ui.activity;

import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

import com.xms.R;
import com.xms.base.BaseFragment;
import com.xms.utils.CommonDialog;

import butterknife.OnClick;

public class MyMessageFragment extends BaseFragment {

    private View mRootView;
    public static final String DF = "mydf";

    @Override
    protected View initView(LayoutInflater inflater) {
        mRootView = inflater.inflate(R.layout.activity_my_message, null);
        return mRootView;
    }

    @Override
    public void initData() {
        setTitle();
        mTvForTitle.setText("个人中心");
        mImgvForLeft.setVisibility(View.INVISIBLE);
    }

    @OnClick({R.id.message_lin_top, R.id.activity_my_message_dl, R.id.activity_my_message_df,
            R.id.activity_my_message_bxgl, R.id.activity_my_message_xtsz, R.id.activity_my_message_kfzx})
    void OnClick(View view) {
        Bundle bundle = new Bundle();
        switch (view.getId()) {
            case R.id.message_lin_top:
                gotoAct(ChangeMessageActivity.class);
                break;
//            case R.id.activity_my_message_dl:
//                bundle.putInt(DF, 0);
//                gotoAct(bundle, DldfActivity.class);
//                break;
//            case R.id.activity_my_message_df:
//                bundle.putInt(DF, 1);
//                gotoAct(bundle, DldfActivity.class);
//                break;
            case R.id.activity_my_message_bxgl:
                gotoAct(BxglActivity.class);
                break;
            case R.id.activity_my_message_xtsz:
                gotoAct(XtszActivity.class);
                break;
            case R.id.activity_my_message_kfzx:
                Dialog("15779160456");
                break;
            default:
                break;
        }
    }
    private void Dialog(final String phone){
        CommonDialog dialog = new CommonDialog(getActivity(),
                R.style.dialog);
        dialog.setIcon(R.mipmap.log);
        dialog.setContent("您是否要拨打客服电话？");
        dialog.setLeftBtnText("取消");
        dialog.setRightBtnText("确定");
        dialog.setListener(new CommonDialog.DialogClickListener() {

            @Override
            public void onRightBtnClick(Dialog dialog) {

                    Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"
                            + phone));
                startActivity(intent);//拨打电话
            }

            @Override
            public void onLeftBtnClick(Dialog dialog) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

}
