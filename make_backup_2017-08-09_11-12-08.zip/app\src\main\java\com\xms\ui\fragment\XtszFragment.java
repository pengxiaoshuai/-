package com.xms.ui.fragment;

import android.view.LayoutInflater;
import android.view.View;

import com.xms.R;
import com.xms.base.BaseFragment;
import com.xms.widget.SwitchView;

import butterknife.BindView;


public class XtszFragment extends BaseFragment {
    private View mRootView;
    @BindView(R.id.switchview01)
    SwitchView mswitchview;
    @BindView(R.id.switchview02)
    SwitchView mswitchview2;
    @Override
    protected View initView(LayoutInflater inflater){
        mRootView = inflater.inflate(R.layout.fragment_xtsz,null);
        return mRootView;
    }

    @Override
    public void initData(){
        mswitchview.setState(true);
        mswitchview2.setState(true);
    }
}
