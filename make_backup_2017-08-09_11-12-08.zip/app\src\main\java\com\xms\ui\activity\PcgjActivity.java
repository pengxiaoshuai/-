package com.xms.ui.activity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Display;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.TextView;

import com.xms.R;
import com.xms.adapter.BaseRecyclerAdapter;
import com.xms.base.BaseActivity;
import com.xms.holder.BaseRecyclerHolder;
import com.xms.inteface.CommonListener;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.OnClick;


public class PcgjActivity extends BaseActivity {
    @BindView(R.id.pcgj_recyclerview)
    RecyclerView mRecyclerview;
    private ArrayList<PcgjBean> mlist;
    private BaseRecyclerAdapter<PcgjBean> madapter;
    @Override
    public int getContentViewId(){
        return R.layout.activity_pcgj;
    }
    @OnClick(R.id.common_title_left)
    void Onclick(View view) {
        switch (view.getId()) {
            case R.id.common_title_left:
                finish();
                break;
            default:
                break;

        }
    }


    @Override
    public void initData() {
        setTitle();
        mTvForTitle.setText("偏差告警");
        mlist=new ArrayList<>();
        initDialog();
        mlist.add(new PcgjBean("莫奈瓷砖","-0.6558","<-0.13|>0.03"));
        madapter=new BaseRecyclerAdapter<PcgjBean>(this,mlist,R.layout.adapter_item_pcgj) {
            @Override
            public void convert(BaseRecyclerHolder holder, PcgjBean item, int position, boolean isScrolling) {
                holder.setText(R.id.adapter_item_pcgj_1,item.getName());
                holder.setText(R.id.adapter_item_pcgj_2,item.getZpcl());
                holder.setText(R.id.adapter_item_pcgj_3,item.getGjfw());
                holder.setCommonListener(R.id.adapter_item_pcgj_4, position, new CommonListener() {
                    @Override
                    public void commonListener(View view, int position){
                     //   ToastUtil.TextToast("设置");
                        dialog.show();
                    }
                });
            }
        };
        mRecyclerview.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerview.setAdapter(madapter);

    }
    private Dialog dialog;
    private ImageButton mright;
    private TextView mtext;
    private void initDialog(){
        dialog=new Dialog(this,R.style.dialog);
        dialog.setContentView(R.layout.dialog_item_gjsz);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
                    return true;
                } else {
                    return false;
                }
            }
        });
        WindowManager windowManager = dialog.getWindow().getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        WindowManager.LayoutParams lp = dialog.getWindow().getAttributes();
        lp.width = (int) (display.getWidth() / 6 * 5); // // 设置宽度
        dialog.getWindow().setAttributes(lp);
        mright = (ImageButton) dialog.findViewById(R.id.common_title_right);
        mtext = (TextView) dialog.findViewById(R.id.dialog_item_gjsz_yy);
        mright.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        mtext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }
    class PcgjBean {
        public PcgjBean(String name, String zpcl, String gjfw) {
            this.name = name;
            this.zpcl = zpcl;
            this.gjfw = gjfw;
        }

        public String getName() {

            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getZpcl() {
            return zpcl;
        }

        public void setZpcl(String zpcl) {
            this.zpcl = zpcl;
        }

        public String getGjfw() {
            return gjfw;
        }

        public void setGjfw(String gjfw) {
            this.gjfw = gjfw;
        }

        private String name;
        private String zpcl;
        private String gjfw;

    }

}
