package com.xms.bean;

import java.util.List;

/**
 * Created by dell on 2017/8/8.
 */

public class SsdlBean {

    /**
     * curDateTime : 1502176878129
     * info : 操作完成
     * recode : 10001000
     * result : {"chartData":{"sData":[{"name":"当天","value":[1664,1544,1296,1320,1448,1648,1664,1744,1720,1584,1568,1568,1488,1440,1424,1344,1720,1712,1720,1712,1712,1736,1760,1576]},{"name":"上一天","value":[1664,1544,1296,1320,1448,1648,1664,1744,1720,1584,1568,1568,1488,1440,1424,1344,1720,1712,1720,1712,1712,1736,1760,1576]},{"name":"去年同期","value":[1664,1544,1296,1320,1448,1648,1664,1744,1720,1584,1568,1568,1488,1440,1424,1344,1720,1712,1720,1712,1712,1736,1760,1576]}],"xData":["01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24"],"yUnit":"24点电量数据"},"companyId":"0ccf0b38-7447-42be-988a-09235320b7d0","day":8,"dayValue":38112,"ddate":"20170808","month":8,"monthValue":0,"year":2017}
     * sessionId : 04C8C2D02F250F57C607C5C399D77503
     * status : y
     * success : true
     */

    private long curDateTime;
    private String info;
    private int recode;
    private ResultBean result;
    private String sessionId;
    private String status;
    private boolean success;

    public long getCurDateTime() {
        return curDateTime;
    }

    public void setCurDateTime(long curDateTime) {
        this.curDateTime = curDateTime;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public int getRecode() {
        return recode;
    }

    public void setRecode(int recode) {
        this.recode = recode;
    }

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public static class ResultBean {
        /**
         * chartData : {"sData":[{"name":"当天","value":[1664,1544,1296,1320,1448,1648,1664,1744,1720,1584,1568,1568,1488,1440,1424,1344,1720,1712,1720,1712,1712,1736,1760,1576]},{"name":"上一天","value":[1664,1544,1296,1320,1448,1648,1664,1744,1720,1584,1568,1568,1488,1440,1424,1344,1720,1712,1720,1712,1712,1736,1760,1576]},{"name":"去年同期","value":[1664,1544,1296,1320,1448,1648,1664,1744,1720,1584,1568,1568,1488,1440,1424,1344,1720,1712,1720,1712,1712,1736,1760,1576]}],"xData":["01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24"],"yUnit":"24点电量数据"}
         * companyId : 0ccf0b38-7447-42be-988a-09235320b7d0
         * day : 8
         * dayValue : 38112
         * ddate : 20170808
         * month : 8
         * monthValue : 0
         * year : 2017
         */

        private ChartDataBean chartData;
        private String companyId;
        private int day;
        private int dayValue;
        private String ddate;
        private int month;
        private int monthValue;
        private int year;

        public ChartDataBean getChartData() {
            return chartData;
        }

        public void setChartData(ChartDataBean chartData) {
            this.chartData = chartData;
        }

        public String getCompanyId() {
            return companyId;
        }

        public void setCompanyId(String companyId) {
            this.companyId = companyId;
        }

        public int getDay() {
            return day;
        }

        public void setDay(int day) {
            this.day = day;
        }

        public int getDayValue() {
            return dayValue;
        }

        public void setDayValue(int dayValue) {
            this.dayValue = dayValue;
        }

        public String getDdate() {
            return ddate;
        }

        public void setDdate(String ddate) {
            this.ddate = ddate;
        }

        public int getMonth() {
            return month;
        }

        public void setMonth(int month) {
            this.month = month;
        }

        public int getMonthValue() {
            return monthValue;
        }

        public void setMonthValue(int monthValue) {
            this.monthValue = monthValue;
        }

        public int getYear() {
            return year;
        }

        public void setYear(int year) {
            this.year = year;
        }

        public static class ChartDataBean {
            /**
             * sData : [{"name":"当天","value":[1664,1544,1296,1320,1448,1648,1664,1744,1720,1584,1568,1568,1488,1440,1424,1344,1720,1712,1720,1712,1712,1736,1760,1576]},{"name":"上一天","value":[1664,1544,1296,1320,1448,1648,1664,1744,1720,1584,1568,1568,1488,1440,1424,1344,1720,1712,1720,1712,1712,1736,1760,1576]},{"name":"去年同期","value":[1664,1544,1296,1320,1448,1648,1664,1744,1720,1584,1568,1568,1488,1440,1424,1344,1720,1712,1720,1712,1712,1736,1760,1576]}]
             * xData : ["01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24"]
             * yUnit : 24点电量数据
             */

            private String yUnit;
            private List<SDataBean> sData;
            private List<String> xData;

            public String getYUnit() {
                return yUnit;
            }

            public void setYUnit(String yUnit) {
                this.yUnit = yUnit;
            }

            public List<SDataBean> getSData() {
                return sData;
            }

            public void setSData(List<SDataBean> sData) {
                this.sData = sData;
            }

            public List<String> getXData() {
                return xData;
            }

            public void setXData(List<String> xData) {
                this.xData = xData;
            }

            public static class SDataBean {
                /**
                 * name : 当天
                 * value : [1664,1544,1296,1320,1448,1648,1664,1744,1720,1584,1568,1568,1488,1440,1424,1344,1720,1712,1720,1712,1712,1736,1760,1576]
                 */

                private String name;
                private List<Integer> value;

                public String getName() {
                    return name;
                }

                public void setName(String name) {
                    this.name = name;
                }

                public List<Integer> getValue() {
                    return value;
                }

                public void setValue(List<Integer> value) {
                    this.value = value;
                }
            }
        }
    }
}
