package com.xms.ui.activity;

import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.xms.R;
import com.xms.base.BaseActivity;
import com.xms.widget.timecheck.JudgeDate;
import com.xms.widget.timecheck.MyAlertDialog;
import com.xms.widget.timecheck.ScreenInfo;
import com.xms.widget.timecheck.WheelMain;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import butterknife.BindView;
import butterknife.OnClick;


public class BxglActivity extends BaseActivity {

    @BindView(R.id.time)
    TextView mtext;
    @BindView(R.id.common_title_tv)
    TextView mtitle;
    @Override
    public int getContentViewId() {
        return R.layout.activity_bxgl;
    }

    @Override
    public void initData() {
        mtitle.setText("报修管理");
    }
    @OnClick({R.id.common_title_left,R.id.bxgl_top,R.id.time,R.id.act_login_login,R.id.common_title_right})
    void OnClick(View view){
        switch (view.getId()){
            case R.id.common_title_left:
                finish();
                break;
            case R.id.bxgl_top:
                break;
            case R.id.time:
                time();
                break;
            case R.id.act_login_login:
                break;
            case R.id.common_title_right:
                gotoActivity(BxjllbActivity.class);
                break;
            default:
                break;
        }
    }
    //时间选择器
    private WheelMain wheelMain;
    private DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    private void time(){
        LayoutInflater inflater1 = LayoutInflater
                .from(BxglActivity.this);
        final View timepickerview1 = inflater1.inflate(R.layout.timepicker,
                null);
        ScreenInfo screenInfo1 = new ScreenInfo(BxglActivity.this);
        wheelMain = new WheelMain(timepickerview1, true, 3);
        wheelMain.screenheight = screenInfo1.getHeight();
        Calendar calendar1 = Calendar.getInstance();
        String time1 = calendar1.get(Calendar.YEAR) + "-"
                + (calendar1.get(Calendar.MONTH) + 1) + "-"
                + calendar1.get(Calendar.DAY_OF_MONTH)
                + calendar1.get(Calendar.HOUR_OF_DAY)
                + calendar1.get(Calendar.MINUTE);
        if (JudgeDate.isDate(time1, "yyyy-mm-dd")) {
            try {
                calendar1.setTime(dateFormat.parse(time1));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        int year = calendar1.get(Calendar.YEAR);
        int month = calendar1.get(Calendar.MONTH);
        int day = calendar1.get(Calendar.DAY_OF_MONTH);
        //需要精确到分就取消注释
//		int hour = calendar1.get(Calendar.HOUR_OF_DAY);
//		int minute = calendar1.get(Calendar.MINUTE);
        wheelMain.initDateTimePicker(year, month, day
                //, hour, minute
        );
        MyAlertDialog dialog = new MyAlertDialog(BxglActivity.this)
                .builder().setTitle("选择日期").setView(timepickerview1)
                .setNegativeButton("取消", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                    }
                });
        dialog.setPositiveButton("确定", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String currentDate = "";
                String format = "yyyy-MM-dd  HH:mm";
                // if (DateUtil.timeCompare(DateUtil.getStringDate(format),
                // wheelMain.getTime("%02d"))) {
                currentDate = wheelMain.getTime("%02d");
                //	String time[] = StringUtil.GetMyMessage(currentDate, " ");
                mtext.setText(currentDate);
            }
        });
        dialog.show();
    }
}
